
package com.crossborder.payments.bopforms.Repo;

import com.crossborder.payments.bopforms.Models.BopFormModel;

import org.springframework.data.jpa.repository.JpaRepository;

public interface BopFormModelRepo extends JpaRepository<BopFormModel, Long> {

}
