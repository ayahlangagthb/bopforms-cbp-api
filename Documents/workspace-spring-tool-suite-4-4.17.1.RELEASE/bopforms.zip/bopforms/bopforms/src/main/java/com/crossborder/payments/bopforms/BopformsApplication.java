package com.crossborder.payments.bopforms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BopformsApplication {

	public static void main(String[] args) {
		SpringApplication.run(BopformsApplication.class, args);
	}

}
