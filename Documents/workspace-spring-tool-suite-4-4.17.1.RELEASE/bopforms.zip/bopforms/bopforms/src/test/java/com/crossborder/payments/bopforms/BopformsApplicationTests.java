package com.crossborder.payments.bopforms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BopformsApplicationTests {

	@Test
	void contextLoads() {
	}

}
